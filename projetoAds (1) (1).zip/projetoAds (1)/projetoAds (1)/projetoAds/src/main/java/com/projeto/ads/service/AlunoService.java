package com.projeto.ads.service;
import org.springframework.stereotype.Service;
import com.projeto.ads.repository.AlunoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import com.projeto.ads.model.Aluno;
import java.util.Date;
import java.util.Calendar;
import java.util.List;

@Service
public class AlunoService {
    @Autowired
    private AlunoRepository alunoRepository;

    public String gerarMatricula(Long id){
        Date data = new Date();
        Calendar calendario = Calendar.getInstance();
        calendario.setTime(data);
        int ano = calendario.get(Calendar.YEAR);
        return "SENAC" + ano + id + 1;

    }

    public String cadastrarAlunoPorCpf(Aluno aluno){
        Aluno alunoAux = alunoRepository.findByCpf(aluno.getCpf());
        if(alunoAux != null){
            return "Já existe um aluno cadastrado com esse CPF!!";
        }
        else 
        {
            Aluno lastAluno = alunoRepository.findLastInsertedAluno();
            if(lastAluno==null)
            aluno.setMatricula(gerarMatricula((long)0));
            alunoRepository.save(aluno);
        }
        return null;
    }
}