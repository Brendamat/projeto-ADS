package com.projeto.ads.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import com.projeto.ads.model.Aluno;
import com.projeto.ads.service.AlunoService;

import org.springframework.web.servlet.ModelAndView;

public class AlunoController {
	
	@Autowired
	AlunoService alunoService;
	
	@PostMapping("/aluno/inserir")
	public ModelAndView insertAlunoPOST (Aluno aluno) {
		ModelAndView mv = new ModelAndView();
		String resposta= alunoService.cadastrarAluno(aluno);
		if (resposta !=null)
		{
			mv.addObject("msg", resposta);
			mv.addObject("aluno", new Aluno());
		}
		else {
			mv.setViewName("Login/index");
		}
		return mv;
	}
	
	@GetMapping ("/aluno/inserir")
	public ModelAndView insertAlunoGET() {
		ModelAndView mv= new ModelAndView();
		mv.addObject("aluno", new Aluno());
		mv.setViewName("Aluno/inserirAluno");
		return mv;
	}

}
